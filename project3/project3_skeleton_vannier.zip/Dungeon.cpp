// CS1300 Spring 2021
// Author: Stella Vannier and Wren Hoertdoerfer
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "Dungeon.h"
#include "PartyMember.h"
#include "Merchant.h"
#include "NPC.h"
#include "Room.h"
#include "Monster.h"
using namespace std;

Dungeon::Dungeon()
{
   foundKey = false;
   string ingredients[50];
   string cookware[50];
   string weaponsArmor[50];
   gold = 100;
   string treasure[15];
   angerLvl = 0;
}
 
void Dungeon::start()
{
   // main driver for the game
}
 
string Dungeon::status()
{
   cout << "----STATUS UPDATE ----" << endl;
   cout << "CURRENT ROOM: " << roomName << endl;
   cout << "ROOM KEY FOUND: " << keyFound << endl;
   cout << "SORCERER ANGER LEVEL: " << angerLvl << " OUT OF 100" << endl;
   cout << "----PARTY MEMBERS ----" << endl;
   cout << "(LEADER) ME: " << fullness[0] << " FULLNESS POINTS" << endl;
   cout << "MEMBER 2: " << fullness[1] << " FULLNESS POINTS" << endl;
   cout << "MEMBER 3: " << fullness[2] << " FULLNESS POINTS" << endl;
   cout << "MEMBER 4: " << fullness[3] << " FULLNESS POINTS" << endl;
   cout << "MEMBER 5: " << fullness[4] << " FULLNESS POINTS" << endl;
   cout << "----MATERIALS ----" << endl;
   cout << "INGREDIENTS: " << totalIngredients << " KG" << endl;
   cout << "COOKWARE: " << endl; // specify the type
   cout << "WEAPONS: " << endl; // specify the type
   cout << "ARMOR: " << endl; // specify the type
   cout << "TREASURE ITEMS: " << endl; // specify the type
 
   // displays the status of: key, players fullness levels,
   // ingredients, cookware, weapons and armor, gold pieces,
   // treasure items, and sorcerer anger level

}
 
string Dungeon::fightMonster()
{
   // use room number to get the level of monster that will be fought
   // get a random monster in the monsters array with the level that matches the room number
   // once a monster is chosen print out "(insert monster name) AHEAD! THEY LOOK HOSTILE!"
   // give the player 2 choices: 1. attack or 2. surrender
   // if they choose 1: (must have at least 1 weapon and 1 armor)
   //      to calculate the outcome of the battle use: (r1*w+d)-(r2*c*(1/a))
   //             w = # of weapons the party possesses + 1 bonus point for each upgraded weapon that is worth 5 gold pieces.
   //             d = 1 if party has 1 of each type of weapon; 0 if not
   //             a = # of sets of armor the party possesses
   //             c = the challenge level of the monster
   //             r1 = random number from 1 to 6
   //             r2 = random number from 1 to 6 (independent of r1)
   //          if the result is greater than 0: the party wins the battle
   //              the party get 50 gold pieces, 20 kg of ingredients
   //              the monster has a 33% chance of dropping the key
   //          if the result is less than or equal to zero: the party loses
   //              the party loses a quarter of their gold reserves, 30 kg of ingredients
   //              individually each party member has a 10% (5% with armor) chance of getting slain by the monster, if a party member is lost: update the total party size
   // if they choose 2:
   //      one person from the party is held hostage by the monster and the rest of the party must proceed without that party member
   // at the end no matter what every member of the partys fullness level drops one point

}
 
string Dungeon::speakToNPC()
{
   // to get to the NPC you must first solve a riddle
   //   if the NPC is good or neurtal:
   //      choose a ramdon riddle from text file
   //          if the player solve the riddle and the NPC is good:
   //              you are offered to buy goods
   //          if the player solve the riddle and the NPC is neutral:
   //              nothing happens
   //          if the player doesnt solve the riddle:
   //              they have failed and you are not offered to buy goods
   //   if the NPC is evil:
   //      you dont solve a puzzle, you fight a monster
   //          call fight monster member function

}
 
string Dungeon::cook()
{
   // prompts action to cook, prompts user for the cookware they want to use 
   // and the ingredients they want to use
   // if the cookware breaks during use, the ingredients are lost, cookware 
   //   removed from inventory, and fullness levels drop one point.
   // if cooking is successful the meal is shared and everyones fullness goes up
   //   1 point for every 5 kg used to cook
   // displays fullness level (if cooking is successful or not)
}
 
string Dungeon::exploreRoom()
{
   // action to explore room
   // 20% chance of finding a key
   // 20% chance of finding treasure (from treasure array in room object)
   // 20% chance of having to fight a monster 
   // all members fullness level drops one point
}
 
string Dungeon::openDoor()
{
   // action to open door, either sucessful or must answer puzzle to get out of trap
   // check if the the party has a key
   // if not: the party must play rock, paper, scissors against the door
   //          get choice from player then generate choice of door
   //          tie = repeat of game
   //          win = escape the trap
   //          they have 3 tries to win else the party loses a team player

}
 
void Dungeon::quitGame()
{

   // ends game.
}
 
string Dungeon::misfortunes()
{
   // 60% chance that this function does nothing

   // 40% chance that...
   // a. party is robbed of food/cookware/armor
   // b. one weapon or armor breaks
   // c. if any player has 0 fullness, they die
   // d. a player gets locked in previous room (only happens after trying to open the door)

   // the game will end if only the leader remains 
}
 
