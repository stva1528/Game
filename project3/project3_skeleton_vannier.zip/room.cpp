// CS1300 Spring 2021
// Author: Stella Vannier and Wren Hoertdoerfer
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "Room.h"
using namespace std;

Room::Room()
{
    // initializes room
}

Room::Room(string)
{
    // reads text file and fills array
}

int Room::getRoomNum()
{
    return roomNum;
}

string Room::getRoomTreasures()
{
    // prints the treasures in roomTreasures array
}

int Room::getRoomNum()
{
    return roomNum;
}
