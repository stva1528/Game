// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef PARTYMEMBER_H
#define PARTYMEMBER_H

class PartyMember
{
    // Data members
    private:
    string name;
    bool armor;
    int weapon;
    int fullness;
    bool leader;

    // Member functions
    public:
    PartyMember();
    PartyMember(string, bool);

    // Setters
    void setName(string);
    void setArmor(bool);
    void setWeapon(int);

    void loseFullness();

    // Getters 
    string getName();
    int getFullness();
    int getArmor();
    int getWeapon();

    bool isLeader();

};

#endif