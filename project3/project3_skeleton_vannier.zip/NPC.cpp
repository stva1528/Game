// CS1300 Spring 2021
// Author: Stella Vannier and Wren Hoertdoerfer
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "NPC.h"
using namespace std;
 
NPC::NPC(string)
{
   // reads the NPC text file
}
 
void NPC::setRiddle(string)
{
   // reads riddle file and makes an array of riddles
}
 
string NPC::getRiddle()
{
   // selects a ramdon riddle from the array of riddles to ask
}
