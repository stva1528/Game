// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "PartyMember.h"
#include "Merchant.h"
#include "NPC.h"
#include "Room.h"
#include "Monster.h"
using namespace std;

#ifndef DUNGEON_H
#define DUNGEON_H

class Dungeon 
{
    private:
    PartyMember teamParty[5];
    int currentRoom;

    bool foundKey;
    int playerFullness[5];
    string ingredients[50];
    string cookware[50];
    string weaponsArmor[50];
    int gold = 100;
    string treasure[100];
    int angerLvl;

    public:
    Dungeon();
    void start();
    void quitGame();

    string status();
    string fightMonster();
    string speakToNPC();
    string cook();
    string exploreRoom();
    string openDoor();

    string misfortunes();

};

#endif