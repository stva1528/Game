// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef MERCHANT_H
#define MERCHANT_H

class Merchant
{
    // Data members
    private:
    string ingredients[100];
    string cookware[100];
    string weapons[100];
    string armor[100];
    int totalCost;

    // Member functions
    public:
    // Getters
    void displayMenu();
    void displayIngredients();
    void displayCookware();
    void displayWeapons();
    void displayArmor();
    void getTotalCost();
    
};

#endif