// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "Monster.h"
using namespace std;

Monster::Monster(string n, int s)
{
    name = n;
    strength = s;
}

string Monster::getName()
{
    return name;
}

int Monster::getStrength()
{
    return strength;
}
