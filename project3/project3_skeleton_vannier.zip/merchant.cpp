// CS1300 Spring 2021
// Author: Stella Vannier and Wren Hoertdoerfer
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "Merchant.h"
using namespace std;

void Merchant::displayMenu()
{
    // displays menu
}

void Merchant::displayIngredients()
{
   // display prompts for ingredients category
}
 
void Merchant::displayCookware()
{
   // display prompts for cookware category
}
 
void Merchant::displayWeapons()
{
   // display prompts for weapons category
}
 
void Merchant::displayArmor()
{
   // display prompts for armor category
}
 
void Merchant::getTotalCost()
{
   // calculated total cost
}
