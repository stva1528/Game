// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef NPC_H
#define NPC_H

class NPC
{
    // Data members
    private:
    bool NPCgood;

    // Member functions
    public:
    NPC(string);

    // Setters
    void setRiddle(string);

    // Getters 
    string getRiddle();
    
};

#endif