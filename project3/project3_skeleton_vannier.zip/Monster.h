// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef MONSTER_H
#define MONSTER_H

class Monster
{
    // Data members
    private:
    string name;
    int strength;

    // Member functions
    public:
    Monster(string, int);  // Sets name and strength

    // Getters 
    string getName();
    int getStrength();

};

#endif