// CS1300 Spring 2021
// Author: Stella Vannier
// Recitation 108 Ani 
// Project 3

#include <iostream>
#include <string>
#include <vector>
#include "PartyMember.h"
using namespace std;

PartyMember::PartyMember()
{
    name = "";
    armor = 1;
    weapon = 0;
    fullness = 10;
    leader = 1;
}

PartyMember::PartyMember(string n, bool l)
{
    name = n;
    leader = l;
    fullness = 10;
    armor = 1;
    weapon = 0;
}

void PartyMember::setName(string n)
{
    name = n;
}

void PartyMember::setArmor(bool a)
{
    armor = a;
}

void PartyMember::setWeapon(int w)
{
    weapon = w;
}

void PartyMember::loseFullness()
{
    fullness--;
}

string PartyMember::getName()
{
    return name;
}

int PartyMember::getFullness()
{
    return fullness;
}

int PartyMember::getArmor()
{
    return armor;
}

int PartyMember::getWeapon()
{
    return weapon;
}

bool PartyMember::isLeader()
{
    return leader;
}